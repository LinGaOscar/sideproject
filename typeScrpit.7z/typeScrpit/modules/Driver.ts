import { customer } from "./customer";

let myCustomer = new customer("lub", "oscar");

console.log(myCustomer.firstName + " " + myCustomer.lastName);