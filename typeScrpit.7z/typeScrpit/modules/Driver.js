"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var customer_1 = require("./customer");
var myCustomer = new customer_1.customer("lub", "oscar");
console.log(myCustomer.firstName + " " + myCustomer.lastName);
