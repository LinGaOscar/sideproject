typescrpit transform and compiler to JS

cmd: tsc --init 
go to file tsconfig.json
set "noEmitOnError": true,
cmd: tsc mydemo.ts => mydemo.js

node mydemo.js