export interface Coach {
    getDailyWorkout(): String;
}