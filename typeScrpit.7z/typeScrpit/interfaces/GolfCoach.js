"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GolfCoach = void 0;
var GolfCoach = /** @class */ (function () {
    function GolfCoach() {
    }
    GolfCoach.prototype.getDailyWorkout = function () {
        return "Hit 100 balls";
    };
    return GolfCoach;
}());
exports.GolfCoach = GolfCoach;
