"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CricketCoach = void 0;
var CricketCoach = /** @class */ (function () {
    function CricketCoach() {
    }
    CricketCoach.prototype.getDailyWorkout = function () {
        return "Practice spin bowling";
    };
    return CricketCoach;
}());
exports.CricketCoach = CricketCoach;
